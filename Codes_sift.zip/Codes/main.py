import process_image as pi

filename='tampered2.jpg'
[num_gt,inliers1, inliers2]=pi.process_image(filename)